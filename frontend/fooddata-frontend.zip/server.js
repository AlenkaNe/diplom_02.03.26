const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3001;

// Настраиваем прокси на бэкенд
const apiProxy = createProxyMiddleware('/foods', {
  target: 'http://localhost:3000',
  changeOrigin: true,
  pathRewrite: {
    '^/foods': '/foods'
  }
});

// Используем прокси для запросов к API
app.use('/foods', apiProxy);

// Обслуживаем статические файлы
app.use(express.static(path.join(__dirname, 'public')));

// Отправляем index.html для всех других запросов
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Запускаем сервер
app.listen(PORT, () => {
  console.log(`Сервер запущен на порту ${PORT}`);
  console.log(`Перейдите по адресу http://localhost:${PORT}`);
});