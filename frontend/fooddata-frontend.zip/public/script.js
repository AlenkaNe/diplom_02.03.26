document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('search-input');
    const searchButton = document.getElementById('search-button');
    const resultsBody = document.getElementById('results-body');
    const noResults = document.getElementById('no-results');
    const loader = document.getElementById('loader');
    const resultsTable = document.getElementById('results-table');
    
    // Скрываем таблицу при загрузке страницы
    resultsTable.style.display = 'none';
    noResults.style.display = 'none';
    
    // Обработчик события для кнопки поиска
    searchButton.addEventListener('click', performSearch);
    
    // Обработчик события для Enter в поле ввода
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            performSearch();
        }
    });
    
    // Функция поиска
    function performSearch() {
        const query = searchInput.value.trim();
        
        if (!query) {
            alert('Пожалуйста, введите текст для поиска');
            return;
        }
        
        // Показываем индикатор загрузки
        loader.style.display = 'block';
        resultsTable.style.display = 'none';
        noResults.style.display = 'none';
        
        // Формируем URL с параметрами
        const url = `/foods/search?query=${encodeURIComponent(query)}&pageSize=20&pageNumber=1`;
        
        // Отправляем GET-запрос на API
        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Ошибка сети или сервера');
                }
                return response.json();
            })
            .then(data => {
                displayResults(data);
            })
            .catch(error => {
                console.error('Ошибка:', error);
                alert('Произошла ошибка при поиске. Попробуйте позже.');
            })
            .finally(() => {
                // Скрываем индикатор загрузки
                loader.style.display = 'none';
            });
    }
    
    // Функция отображения результатов
    function displayResults(foods) {
        // Очищаем предыдущие результаты
        resultsBody.innerHTML = '';
        
        if (foods && foods.length > 0) {
            // Показываем таблицу
            resultsTable.style.display = 'table';
            noResults.style.display = 'none';
            
            // Заполняем таблицу данными
            foods.forEach(food => {
                const row = document.createElement('tr');
                
                row.innerHTML = `
                    <td>${food.id}</td>
                    <td>${food.description || '-'}</td>
                    <td>${food.brandName || '-'}</td>
                    <td>${food.ingredients || '-'}</td>
                    <td>${food.servingSize ? food.servingSize + ' ' + (food.servingSizeUnit || '') : '-'}</td>
                `;
                
                resultsBody.appendChild(row);
            });
        } else {
            // Если результатов нет
            resultsTable.style.display = 'none';
            noResults.style.display = 'block';
        }
    }
});